#!/system/bin/sh
##########################################################################################
# POCO F4 (munch) 144Hz Display Mod Uninstaller
# Author: fatidaprilian
##########################################################################################

# 1. Restore factory stock DTBO if backup exists
if [ -f /data/adb/munch_stock_dtbo.img ]; then
  for part in "dtbo_a" "dtbo_b" "dtbo"; do
    for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
      if [ -b "$path" ] || [ -e "$path" ]; then
        dd if=/data/adb/munch_stock_dtbo.img of="$path" bs=4096 2>/dev/null
        break
      fi
    done
  done
  rm -f /data/adb/munch_stock_dtbo.img
fi

# 2. Reset display settings database back to factory stock 120Hz
settings delete system min_refresh_rate 2>/dev/null
settings put system peak_refresh_rate 120.0 2>/dev/null
settings put system user_refresh_rate 120 2>/dev/null
