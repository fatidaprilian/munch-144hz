#!/sbin/sh
choose_key() {
  local timeout=${1:-8}
  local start now key
  start=$(date +%s)
  while true; do
    key=$(timeout 0.2 getevent -qlc 1 2>/dev/null)
    case "$key" in
      *"KEY_VOLUMEUP"*"DOWN"*|*"KEY_VOLUMEUP"*" 1"*|*"KEY_VOLUMEUP"*"down"*)
        echo "UP"
        return 0
        ;;
      *"KEY_VOLUMEDOWN"*"DOWN"*|*"KEY_VOLUMEDOWN"*" 1"*|*"KEY_VOLUMEDOWN"*"down"*)
        echo "DOWN"
        return 0
        ;;
    esac
    now=$(date +%s)
    if [ $((now - start)) -ge $timeout ]; then
      echo "TIMEOUT"
      return 0
    fi
  done
}

ui_print "--------------------------------------------------"
ui_print "  POCO F4 (munch) 144Hz Display Mod               "
ui_print "  Author: fatidaprilian                           "
ui_print "  GitHub: https://github.com/fatidaprilian/munch-144hz "
ui_print "--------------------------------------------------"

ui_print " "
ui_print "--> Select Installation Mode:"
ui_print "  (Vol +) Auto Detect ROM"
ui_print "  (Vol -) Manual Selection"

CHOICE=$(choose_key 8)

if [ "$CHOICE" = "DOWN" ]; then
  ui_print " "
  ui_print "--> Select your ROM type:"
  ui_print "  (Vol +) MIUI / HyperOS"
  ui_print "  (Vol -) AOSP / Custom ROM"
  
  ROM_CHOICE=$(choose_key 10)
  if [ "$ROM_CHOICE" = "DOWN" ]; then
    ui_print "  Selected: AOSP / Custom ROM"
    TARGET_ROM="aosp"
  else
    ui_print "  Selected: MIUI / HyperOS"
    TARGET_ROM="miui"
  fi
else
  ui_print "  Selected: Auto Detect"
  IS_MIUI=0
  for prop in "ro.miui.ui.version.name" "ro.miui.ui.version.code" "ro.build.version.incremental"; do
    val=$(getprop "$prop" 2>/dev/null)
    if [ -n "$val" ]; then
      case "$val" in
        *V12*|*V13*|*V14*|*OS1*|*MIUI*|*HyperOS*) IS_MIUI=1; break ;;
      esac
    fi
  done
  if [ "$IS_MIUI" -eq 0 ] && [ -f "/system/build.prop" ]; then
    grep -qi "miui" /system/build.prop 2>/dev/null && IS_MIUI=1
  fi
  if [ -f "/product/etc/device_features/munch.xml" ] || [ -f "/vendor/etc/device_features/munch.xml" ]; then
    IS_MIUI=1
  fi

  if [ "$IS_MIUI" -eq 1 ]; then
    ui_print "  --> Detected: MIUI / HyperOS"
    TARGET_ROM="miui"
  else
    ui_print "  --> Detected: AOSP / Custom ROM"
    TARGET_ROM="aosp"
  fi
fi

ui_print " "
DTBO_BLK=""
for part in "dtbo_a" "dtbo_b" "dtbo"; do
  for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
    if [ -b "$path" ] || [ -e "$path" ]; then
      DTBO_BLK="$path"
      break 2
    fi
  done
done

if [ -n "$DTBO_BLK" ] && [ ! -f /data/adb/munch_stock_dtbo.img ]; then
  ui_print "--> Backing up stock DTBO..."
  dd if="$DTBO_BLK" of="/data/adb/munch_stock_dtbo.img" bs=4096 2>/dev/null
fi

ui_print "--> Flashing 144Hz DTBO..."
FLASHED=0
for part in "dtbo_a" "dtbo_b" "dtbo"; do
  for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
    if [ -b "$path" ] || [ -e "$path" ]; then
      dd if="$MODPATH/dtbo.img" of="$path" bs=4096 2>/dev/null && FLASHED=1
      break
    fi
  done
done

if [ "$FLASHED" -eq 1 ]; then
  ui_print "  [+] DTBO flashed successfully."
fi

ui_print " "
if [ "$TARGET_ROM" = "miui" ]; then
  ui_print "--> Configuring MIUI/HyperOS..."
  ui_print "  [+] 144Hz enabled in Settings"
  ui_print "  [+] DC Dimming enabled"
  ui_print "  [+] Idle-drop fix enabled"
else
  ui_print "--> Configuring AOSP..."
  ui_print "  [+] 144Hz active"
  rm -rf "$MODPATH/system"
fi

chmod 0755 "$MODPATH/service.sh" 2>/dev/null
chmod 0755 "$MODPATH/uninstall.sh" 2>/dev/null

ui_print " "
ui_print "--------------------------------------------------"
ui_print "  Installation completed. Please reboot.          "
ui_print "--------------------------------------------------"
