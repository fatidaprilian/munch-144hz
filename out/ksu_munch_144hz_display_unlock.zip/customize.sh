#!/sbin/sh
##########################################################################################
# POCO F4 (munch) 144Hz Display Mod Customization Script
# Author: fatidaprilian
##########################################################################################

choose_key() {
  local timeout=${1:-8}
  local start now key
  start=$(date +%s)
  while true; do
    key=$(timeout 0.2 getevent -qlc 1 2>/dev/null)
    case "$key" in
      *"KEY_VOLUMEUP"*"DOWN"*|*"KEY_VOLUMEUP"*" 1"*|*"KEY_VOLUMEUP"*"down"*)
        echo "UP"
        return 0
        ;;
      *"KEY_VOLUMEDOWN"*"DOWN"*|*"KEY_VOLUMEDOWN"*" 1"*|*"KEY_VOLUMEDOWN"*"down"*)
        echo "DOWN"
        return 0
        ;;
    esac
    now=$(date +%s)
    if [ $((now - start)) -ge $timeout ]; then
      echo "TIMEOUT"
      return 0
    fi
  done
}

ui_print "--------------------------------------------------"
ui_print "  POCO F4 (munch) 144Hz Display Mod               "
ui_print "  Author: fatidaprilian                           "
ui_print "  GitHub: https://github.com/fatidaprilian/munch-144hz "
ui_print "--------------------------------------------------"

ui_print " "
ui_print "--> Select Installation Mode:"
ui_print "  (Vol +) Auto Detect ROM"
ui_print "  (Vol -) Manual Selection"
ui_print "  ! Timeout in 8s defaults to Auto Detect"

CHOICE=$(choose_key 8)
TARGET_ROM=""

if [ "$CHOICE" = "DOWN" ]; then
  ui_print "  Selected: Manual Selection"
  ui_print " "
  ui_print "--> Select Your ROM Type:"
  ui_print "  (Vol +) MIUI / HyperOS"
  ui_print "  (Vol -) AOSP / Custom ROM"
  
  ROM_CHOICE=$(choose_key 15)
  if [ "$ROM_CHOICE" = "DOWN" ]; then
    ui_print "  Selected: AOSP / Custom ROM"
    TARGET_ROM="aosp"
  else
    ui_print "  Selected: MIUI / HyperOS"
    TARGET_ROM="miui"
  fi
else
  if [ "$CHOICE" = "TIMEOUT" ]; then
    ui_print "  ! Timeout reached, defaulting to Auto Detect..."
  else
    ui_print "  Selected: Auto Detect"
  fi
  
  # Auto detection logic
  IS_MIUI=0
  for prop in "ro.miui.ui.version.name" "ro.miui.ui.version.code" "ro.build.version.incremental"; do
    val=$(getprop "$prop" 2>/dev/null)
    if [ -n "$val" ]; then
      case "$val" in
        *V12*|*V13*|*V14*|*OS1*|*MIUI*|*HyperOS*) IS_MIUI=1; break ;;
      esac
    fi
  done
  
  if [ "$IS_MIUI" -eq 0 ]; then
    if [ -f "/system/build.prop" ]; then
      if grep -qi "miui" /system/build.prop 2>/dev/null; then
        IS_MIUI=1
      fi
    fi
  fi
  
  if [ -f "/product/etc/device_features/munch.xml" ] || [ -f "/vendor/etc/device_features/munch.xml" ]; then
    IS_MIUI=1
  fi
  
  if [ "$IS_MIUI" -eq 1 ]; then
    ui_print "  --> Detected: MIUI / HyperOS"
    TARGET_ROM="miui"
  else
    ui_print "  --> Detected: AOSP / Custom ROM"
    TARGET_ROM="aosp"
  fi
fi

ui_print " "
ui_print "--> Flashing Calibrated 144Hz DTBO..."
FLASHED=0
for part in "dtbo_a" "dtbo_b" "dtbo"; do
  for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
    if [ -b "$path" ] || [ -e "$path" ]; then
      ui_print "  Flashing to $part ($path)..."
      if dd if="$MODPATH/dtbo.img" of="$path" bs=4096 2>/dev/null; then
        FLASHED=1
      elif cat "$MODPATH/dtbo.img" > "$path" 2>/dev/null; then
        FLASHED=1
      fi
      break
    fi
  done
done

if [ "$FLASHED" -eq 1 ]; then
  ui_print "  [+] DTBO flashed successfully! (0-nit black, scanline-free, 1:1 brightness)"
else
  ui_print "  [!] Notice: DTBO block device not found directly."
  ui_print "      Please also flash twrp_munch_144hz_display_unlock.zip in TWRP if DTBO was not written."
fi

ui_print " "
if [ "$TARGET_ROM" = "miui" ]; then
  ui_print "--> Configuring MIUI/HyperOS Display Settings..."
  ui_print "  [+] Systemless overlay applied to device_features/munch.xml"
  ui_print "  [+] 144Hz option enabled in Settings -> Display -> Refresh rate"
else
  ui_print "--> Configuring AOSP..."
  ui_print "  [+] AOSP displays read 144Hz natively from DTBO timings."
  ui_print "  [*] Removing MIUI overlay to keep system 100% clean."
  rm -rf "$MODPATH/system"
fi

# Set executable permission for background auto-guard service
chmod 0755 "$MODPATH/service.sh" 2>/dev/null

ui_print " "
ui_print "--------------------------------------------------"
ui_print "  Installation completed successfully!            "
ui_print "  Please reboot your device.                      "
ui_print "--------------------------------------------------"
