#!/sbin/sh
ui_print "- POCO F4 (munch) 144Hz Display Mod"
ui_print "- Author: fatidaprilian"
ui_print "- GitHub: https://github.com/fatidaprilian/munch-144hz"

if [ -f "$MODPATH/stock_dtbo.img" ]; then
  mkdir -p /data/adb 2>/dev/null
  cp -f "$MODPATH/stock_dtbo.img" /data/adb/munch_stock_dtbo.img 2>/dev/null
fi

FLASHED=0
for part in "dtbo_a" "dtbo_b" "dtbo"; do
  for path in     "/dev/block/bootdevice/by-name/$part"     "/dev/block/by-name/$part"     "/dev/block/mapper/$part"     $(find /dev/block -iname "$part" 2>/dev/null); do
    if [ -b "$path" ]; then
      ui_print "- Flashing 144Hz DTBO to $path..."
      dd if="$MODPATH/dtbo.img" of="$path" bs=4096 2>/dev/null
      FLASHED=1
      break
    fi
  done
done

if [ "$FLASHED" -eq 1 ]; then
  ui_print "- DTBO flashed successfully."
else
  ui_print "! Warning: DTBO partition not found."
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 0755 "$MODPATH/uninstall.sh" "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/action.sh" 2>/dev/null
ui_print "- Done. Please reboot."
