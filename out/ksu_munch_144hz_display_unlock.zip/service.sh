#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion with a safe timeout (max 30s)
BOOT_WAIT=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$BOOT_WAIT" -lt 15 ]; do
  sleep 2
  BOOT_WAIT=$((BOOT_WAIT + 1))
done
sleep 2

# Low-latency gaming touch mode activation (one-time, non-blocking)
for node in   /sys/class/touch/touch_dev/touch_game_mode   /proc/touchpanel/game_switch_enable   /sys/class/touch/touch_dev/touch_active; do
  if [ -f "$node" ]; then
    echo 1 > "$node" 2>/dev/null
  fi
done

# One-time hardware status verification (runs once in <2ms, NO loop!)
if cat /sys/class/drm/*/modes 2>/dev/null | grep -q "144"; then
  STATUS="Active (144Hz)"
else
  STATUS="Inactive (120Hz detected, kernel update overwrote DTBO - please reflash module)"
fi

DESC="Enables 144Hz display mode. Status: $STATUS"

if command -v ksud >/dev/null 2>&1; then
  ksud module config set override.description "$DESC" 2>/dev/null
fi
sed -i "s/^description=.*/description=$DESC/" "$MODDIR/module.prop" 2>/dev/null

(
  LAST_FPS=""
  while true; do
    CURR_FPS=$(settings get system user_refresh_rate 2>/dev/null)
    if [ "$CURR_FPS" != "$LAST_FPS" ]; then
      case "$CURR_FPS" in
        144)
          settings put system min_refresh_rate 144.0 2>/dev/null
          settings put system peak_refresh_rate 144.0 2>/dev/null
          ;;
        120)
          settings put system min_refresh_rate 120.0 2>/dev/null
          settings put system peak_refresh_rate 120.0 2>/dev/null
          ;;
        60)
          settings put system min_refresh_rate 60.0 2>/dev/null
          settings put system peak_refresh_rate 60.0 2>/dev/null
          ;;
      esac
      LAST_FPS="$CURR_FPS"
    fi
    sleep 4
  done
) &
