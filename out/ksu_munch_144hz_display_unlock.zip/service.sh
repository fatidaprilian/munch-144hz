#!/system/bin/sh
##########################################################################################
# POCO F4 (munch) 144Hz Auto-Guard Service
# Author: fatidaprilian
##########################################################################################

MODDIR=${0%/*}

# Wait for boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

# Wait 5s for system settling
sleep 5

[ -f "$MODDIR/dtbo.img" ] || exit 0

DTBO_BLK=""
for part in "dtbo_a" "dtbo_b" "dtbo"; do
  for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
    if [ -b "$path" ] || [ -e "$path" ]; then
      DTBO_BLK="$path"
      break 2
    fi
  done
done

[ -n "$DTBO_BLK" ] || exit 0

DTBO_SIZE=$(wc -c < "$MODDIR/dtbo.img")
CHECK_TMP="/data/local/tmp/dtbo_check"

# Read payload size from partition
dd if="$DTBO_BLK" of="$CHECK_TMP" bs=4096 count=$(( (DTBO_SIZE + 4095) / 4096 )) 2>/dev/null

if [ -f "$CHECK_TMP" ]; then
  if ! cmp -s -n "$DTBO_SIZE" "$MODDIR/dtbo.img" "$CHECK_TMP"; then
    # Overwritten partition detected! Restore 144Hz DTBO
    for part in "dtbo_a" "dtbo_b" "dtbo"; do
      for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
        if [ -b "$path" ] || [ -e "$path" ]; then
          dd if="$MODDIR/dtbo.img" of="$path" bs=4096 2>/dev/null
          break
        fi
      done
    done

    # Notify user that DTBO was restored and a restart is needed
    cmd notification post -S bigtext -t "POCO F4 144Hz" "Tag144" "Kernel update detected! 144Hz DTBO was automatically restored. Please restart your phone to apply." 2>/dev/null
  fi
  rm -f "$CHECK_TMP"
fi
