#!/system/bin/sh
##########################################################################################
# POCO F4 (munch) 144Hz Auto-Guard & Refresh Rate Auto-Lock Service
# Author: fatidaprilian
##########################################################################################

MODDIR=${0%/*}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

sleep 5

# Auto-guard against kernel updates overwriting DTBO
if [ -f "$MODDIR/dtbo.img" ]; then
  DTBO_BLK=""
  for part in "dtbo_a" "dtbo_b" "dtbo"; do
    for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
      if [ -b "$path" ] || [ -e "$path" ]; then
        DTBO_BLK="$path"
        break 2
      fi
    done
  done

  if [ -n "$DTBO_BLK" ]; then
    DTBO_SIZE=$(wc -c < "$MODDIR/dtbo.img")
    CHECK_TMP="/data/local/tmp/dtbo_check"
    dd if="$DTBO_BLK" of="$CHECK_TMP" bs=4096 count=$(( (DTBO_SIZE + 4095) / 4096 )) 2>/dev/null

    if [ -f "$CHECK_TMP" ]; then
      if ! cmp -s -n "$DTBO_SIZE" "$MODDIR/dtbo.img" "$CHECK_TMP"; then
        for part in "dtbo_a" "dtbo_b" "dtbo"; do
          for path in "/dev/block/bootdevice/by-name/$part" "/dev/block/by-name/$part" "/dev/block/mapper/$part"; do
            if [ -b "$path" ] || [ -e "$path" ]; then
              dd if="$MODDIR/dtbo.img" of="$path" bs=4096 2>/dev/null
              break
            fi
          done
        done
        cmd notification post -S bigtext -t "POCO F4 144Hz" "Tag144" "Kernel update detected! 144Hz DTBO was automatically restored. Please restart your phone to apply." 2>/dev/null
      fi
      rm -f "$CHECK_TMP"
    fi
  fi
fi

# Settings Synchronizer & Zero Idle-Drop Daemon
(
  LAST_FPS=""
  while true; do
    CURR_FPS=$(settings get system user_refresh_rate 2>/dev/null)
    if [ "$CURR_FPS" != "$LAST_FPS" ]; then
      case "$CURR_FPS" in
        144)
          settings put system min_refresh_rate 144.0 2>/dev/null
          settings put system peak_refresh_rate 144.0 2>/dev/null
          ;;
        120)
          settings put system min_refresh_rate 120.0 2>/dev/null
          settings put system peak_refresh_rate 120.0 2>/dev/null
          ;;
        60)
          settings put system min_refresh_rate 60.0 2>/dev/null
          settings put system peak_refresh_rate 60.0 2>/dev/null
          ;;
      esac
      LAST_FPS="$CURR_FPS"
    fi
    sleep 4
  done
) &
