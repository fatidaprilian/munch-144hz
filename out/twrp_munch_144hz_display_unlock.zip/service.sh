#!/system/bin/sh
MODDIR=${0%/*}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done
sleep 3

(
  LAST_FPS=""
  while true; do
    CURR_FPS=$(settings get system user_refresh_rate 2>/dev/null)
    if [ "$CURR_FPS" != "$LAST_FPS" ]; then
      case "$CURR_FPS" in
        144)
          settings put system min_refresh_rate 144.0 2>/dev/null
          settings put system peak_refresh_rate 144.0 2>/dev/null
          ;;
        120)
          settings put system min_refresh_rate 120.0 2>/dev/null
          settings put system peak_refresh_rate 120.0 2>/dev/null
          ;;
        60)
          settings put system min_refresh_rate 60.0 2>/dev/null
          settings put system peak_refresh_rate 60.0 2>/dev/null
          ;;
      esac
      LAST_FPS="$CURR_FPS"
    fi
    sleep 4
  done
) &
