#!/system/bin/sh
echo "POCO F4 144Hz Display Mod"
echo "Author: fatidaprilian"
echo "GitHub: https://github.com/fatidaprilian/munch-144hz"
echo "Current refresh rate:"
dumpsys display | grep -E "mCurrentRefreshRate|mBaseDisplayInfo" | head -n 3
