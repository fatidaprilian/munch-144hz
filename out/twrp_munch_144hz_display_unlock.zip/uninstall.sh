#!/system/bin/sh
MODDIR="${0%/*}"

STOCK_IMG=""
if [ -f "$MODDIR/stock_dtbo.img" ]; then
  STOCK_IMG="$MODDIR/stock_dtbo.img"
elif [ -f "/data/adb/munch_stock_dtbo.img" ]; then
  STOCK_IMG="/data/adb/munch_stock_dtbo.img"
fi

if [ -n "$STOCK_IMG" ] && [ -f "$STOCK_IMG" ]; then
  for part in "dtbo_a" "dtbo_b" "dtbo"; do
    for path in       "/dev/block/bootdevice/by-name/$part"       "/dev/block/by-name/$part"       "/dev/block/mapper/$part"       $(find /dev/block -iname "$part" 2>/dev/null); do
      if [ -b "$path" ]; then
        dd if="$STOCK_IMG" of="$path" bs=4096 2>/dev/null
        break
      fi
    done
  done
fi

settings delete system min_refresh_rate 2>/dev/null
settings put system peak_refresh_rate 120.0 2>/dev/null
settings put system user_refresh_rate 120 2>/dev/null
rm -f /data/adb/munch_stock_dtbo.img 2>/dev/null
exit 0
