#!/system/bin/sh
MODDIR="${0%/*}"

if [ -f "$MODDIR/remove" ]; then
  if [ -f "$MODDIR/uninstall.sh" ]; then
    sh "$MODDIR/uninstall.sh"
  fi
fi
